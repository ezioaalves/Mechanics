# Combat Expertise

You are skilled at using your combat training for defense as well as offense.

**Prerequisite**: Intelligence 13.

**Benefit**: When the character uses the attack action or the full attack action in melee, the character can take a penalty of up to -5 on his or her attack roll and add the same number (up to +5) to the character's Defense. This number may not exceed the character's Base Attack Bonus. The changes to attack rolls and Defense last until the character's next action. The bonus to the character's Defense is a dodge bonus (and as such it stacks with other dodge bonuses the character may have).

**Normal**: A character without the Combat Expertise feat can fight defensively while using the attack or full attack action to take a -4 penalty on attacks and gain a +2 dodge bonus to Defense.
