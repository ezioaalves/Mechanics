# Far Shot

You get greater range out of ranged weapons.

**Benefit**: When the character uses a firearm or archaic ranged weapon, its range increment increases by one-half (multiply by 1.5). When the character throws a weapon, its range increment is doubled.
