# Cleave

You can follow through with a powerful melee attack.

**Prerequisite**: Strength 13, [Universal: Risky Strike]

**Benefit**: If the character deals an opponent enough damage to make the opponent drop (either by knocking the opponent out due to massive damage or by reducing the opponent's hit points to less than 0), the character gets an immediate extra melee attack against another opponent adjacent to the character. The character can't take a 5-foot step before making this extra attack. The extra attack is with the same weapon and at the same bonus as the attack that dropped the previous opponent. The character can use this ability once per round.
