# Living Puppeteer

The Living Puppeteer is a shinobi who specializes in the creation of puppets made from the carcasses of animals and the bodies of humans. His ability to do so has increased his skill as a puppeteer manyfold but often comes at the price of a certain level of infamy.

The living puppeteer is often shunned for his affinity with human puppets and ability to turn a once perfectly normal human body into an ambulating parody of its former self, but the degree to which he is able to do so is often bemusing.

## Requirements
To qualify to become a living puppeteer, a character must fulfill all the following criteria.
**Skills:** Concentration 12 ranks, Craft (mechanical) 12 ranks, Knowledge (earth and life science) 12 ranks, Ninjutsu 12 ranks.
**Feats:** Craft Living Puppet, Craft Puppets.
**Special:** Advanced Puppetry II class feature. 
The living puppeteer candidate must be able to create B-Class or better chakra threads with the Ninpou: Chakra no Ito technique.

## Class Information
The following information pertains to the Living Puppeteer prestige class.

**Hit Die**
The Living Puppeteer gains 1d6 hit points per level. The Constitution modifier applies.

**Action Points**
The Living Puppeteer gains a number of action points equal to 7 + one-half his character level, rounded down, everytime he attains a new level in this class.

**Class Skills**
The Living Puppeteer's class skills are as follows.
Chakra Control (Wis), Craft (chemical, mechanical) (Int), Concentration (Con), Disable Device (Int), Drive (Dex), Escape Artist (Dex), Genjutsu (Cha), Hide (Dex), Knowledge (earth and life science, ninja lore, popular culture, streetwise, technology) (Int), Listen (Wis), Ninjutsu (Int), Perform (Cha), Pilot (Dex), Profession (Wis), Read Language (None), Repair (Int), Ride (Dex), Search (Int), Speak Language (None), Spot (Wis), Treat Injury (Wis).
**Skill Points at Each Level:** 7 + Int modifier.

### TABLE: THE LIVING PUPPETEER

| Level | Base Attack Bonus | Fort Save | Ref Save | Will Save | Special | Defense Bonus | Reputation Bonus |
| :---: | :---: | :---: | :---: | :---: | :--- | :---: | :---: |
| 1st | +0 | +1 | +1 | +1 | Living puppetry, advanced puppetry, bonus chakra | +1 | +1 |
| 2nd | +1 | +2 | +2 | +2 | Puppeteer skill | +1 | +1 |
| 3rd | +1 | +2 | +2 | +2 | Innate mastery | +2 | +1 |
| 4th | +2 | +2 | +2 | +2 | Puppeteer skill | +2 | +2 |
| 5th | +2 | +3 | +3 | +3 | Technique preservation | +3 | +2 |
| 6th | +3 | +3 | +3 | +3 | Puppeteer skill | +3 | +2 |
| 7th | +3 | +4 | +4 | +4 | Bloodline preservation | +4 | +3 |

## Class Features
The following features pertain to the Living Puppeteer prestige class.

### Living Puppetry
The living puppeteer's skill when creating human puppets is baffling. When using a human puppet or animal puppet created by the living puppeteer after obtaining this ability, the puppet retains all weapon proficiencies and proficiencies with natural attacks.

The maximum bonus chakra a human or animal puppet can be crafted with increases by 1. The living puppeteer gains a +1 bonus to Learn checks every odd-numbered level in this class with techniques that require the Living Puppetry, Puppetry or Advanced Puppetry class abilities to be learned.

### Advanced Puppetry
The living puppeteer's ability continues to progress normally. Each level of living puppeteer stacks with levels in the puppeteer class to progress the Advanced Puppetry ability.

### Bonus Chakra
The Living Puppeteer gains a certain amount of bonus chakra and bonus reserve from taking levels in this class. The amount of bonus chakra or chakra reserve gained is shown on the table below. It is not influenced by ability scores, and is in addition to the standard amount gained every level from gaining an additional hit dice.

The amount of bonus chakra or reserve doesn't stack, simply choose the appropriate value based on the character's class levels. Multiple instances of Bonus Chakra and Reserve, such as from various classes, do stack with each other.

| Class Levels | Bonus Chakra | Bonus Reserve |
| :---: | :---: | :---: |
| 1st | 1 | 2 |
| 2nd | 2 | 4 |
| 3rd | 3 | 6 |
| 4th | 4 | 8 |
| 5th | 5 | 10 |
| 6th | 6 | 12 |
| 7th | 7 | 14 |
| 8th | 8 | 16 |
| 9th | 9 | 18 |
| 10th | 10 | 20 |

### Puppeteer Skill
The living puppeteer may select a Puppeteer Skill from the list provided in the Puppeteer class ability of the same name, as well as the following abilities.

**Lifelike Ninjutsu:** The living puppeteer is able to use a human puppet to deliver a Ninjutsu technique as though it was the living puppeteer itself. A cone-shaped burst from the user, for example, could originate from the human puppet if the living puppeteer chose. In this case, both the puppet and the living puppeteer provoke attacks of opportunity, but the puppet doesn't have a chance to be disrupted.

**Puppet Weapon Focus:** When crafting an animal or human puppet, the living puppeteer designates a single mode of attack, individual to each puppet and including natural attacks and attacks with a specific weapon, to apply the benefits of this puppeteer skill to. 
Any attack made with that weapon or natural attack gains a +1 bonus to attack roll. This puppeteer skill can be selected multiple times; each time, it applies to a different weapon or natural attack

**Puppet Weapon Specialization** (requires Puppet Weapon Focus): When crafting an animal or human puppet, the living puppeteer designates a single mode of attack, individual to each puppet and including natural attacks and attacks with a specific weapon, to apply the benefits of this puppeteer skill to. 
Any successful attack made with that weapon or natural attack gains a +2 bonus to damage. This puppeteer skill can be selected multiple times; each time, it applies to a different weapon or natural attack

**True Technique Preservation** (requires Technique Preservation): When using the Technique Preservation ability, the living puppeteer may also build in Genjutsu and Taijutsu techniques instead of only Ninjutsu.

**Instinct Recall:** When crafting a human or animal puppet, the living puppeteer may choose to retain a single one of its extraordinary abilities, if it had any. This ability can only be accessed by a living puppeteer with this puppeteer skill.
Any damage reduction or energy resistance cannot exceed the living puppeteer's level plus 3. Chakra resistance is limited to 10 + the living puppeteer's class level, while a living puppet with the chakra immunity ability cannot be animated. Trip, improved grab, rake and constrict attacks all take a -4 penalty to attack and damage rolls.

Doing so increases the Craft check by 5 and the Wealth check difficulty class by 8.

### Innate Mastery
The living puppeteer gains a circumstance bonus to attack rolls and skill checks when animating an animal or human puppet to certain degrees. A puppet animated with a number of hit dice equal to the living puppeteer's class level plus his Puppeteer class level grants a +1 bonus to attack rolls and skill checks. This bonus does not apply if the puppet is more than 30 feet away. 

The maximum bonus chakra a human or animal puppet can be crafted with increases by 3. This does not stack with other such increases.

### Technique Preservation
During the process to create a human puppet, the living puppeteer is able to study a great deal of its physiology and learn a great deal about the base creature's skill in life. 
The living puppeteer may make an Intelligence check and add his living puppeteer level to the result of that check to learn one of the base creature's most frequently used Ninjutsu techniques per point of his Intelligence modifier, up to a maximum of half his living puppeteer level, round up. The check is made against the technique's Learn DC, requiring only one success; if the living puppeteer already knows the technique, or has preserved the technique before, this process only takes a half day. The time spent building in the technique is equal to the time spent attempting one success. A retry is not possible.

The techniques learned can only be used when the human puppet is animated with a number of hit dice equal to or higher than the living puppeteer's class levels. The techniques originate from the human puppet as though the puppet had used the techniques, but the living puppeteer must still pay the chakra cost and other associated costs himself, such as XP costs. Using this technique with the puppet does not facilitate learning the same technique for the living puppeteer.

This process increases the time to create a human puppet by a number of days equal to the time spent learning the selected techniques, and increases the Craft check and wealth check DC by 2 per techniques.

If the human puppet is disabled or destroyed, the techniques can no longer be used until the puppet is repaired and reanimated. The human puppet is unable to deliver gaze effects, use Spacetime techniques or techniques that would normally allow it to teleport (as special ability), avoidance or defensive maneuvers, and does not gain the benefits of training techniques. The human puppet is unable to learn techniques that create real duplicate of itself, or techniques and abilities that allow it to control another creature or object, such as the Puppetry ability.

The maximum bonus chakra a human or animal puppet can be crafted with increases by 5. This does not stack with other such increases.

### Bloodline Preservation
The living puppeteer's skill with the creation of human puppets is so great that he is able to impart a puppet with a bloodline the base creature possessed in life.

Doing so increases the Craft check DC by 15 and the wealth check DC by 10. The base creature's effective level is halved to determine the power of the bloodline, and the bloodline never progresses further after it was imparted on a puppet.

If a bloodline ability has a chakra cost, the cost is paid directly from the puppet's chakra pool. The puppet does not benefit from insight bonus, morale bonus, speed and strength ranks. 

The living puppeteer cannot use this ability to impart a Doujutsu bloodline, and the process costs experience points: 150 XP for a minor bloodline, 300 XP for an intermediate bloodline and 500 XP for a major bloodline.